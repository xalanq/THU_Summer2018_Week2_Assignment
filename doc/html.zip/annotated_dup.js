var annotated_dup =
[
    [ "Chess", "dd/d08/namespaceChess.html", "dd/d08/namespaceChess" ],
    [ "ChessWidget", "d3/d6b/classChessWidget.html", "d3/d6b/classChessWidget" ],
    [ "ClientDialog", "d1/d8f/classClientDialog.html", "d1/d8f/classClientDialog" ],
    [ "LoadingDialog", "d3/dd5/classLoadingDialog.html", "d3/dd5/classLoadingDialog" ],
    [ "MainWindow", "d6/d1a/classMainWindow.html", "d6/d1a/classMainWindow" ],
    [ "PanelWidget", "d3/d3b/classPanelWidget.html", "d3/d3b/classPanelWidget" ],
    [ "ServerDialog", "d2/d58/classServerDialog.html", "d2/d58/classServerDialog" ]
];