var classServerDialog =
[
    [ "ServerDialog", "d2/d58/classServerDialog.html#af2ce13bfa5d8c5d51695aaafeed1015e", null ],
    [ "~ServerDialog", "d2/d58/classServerDialog.html#a05ac011efd88d4ae6f0965f7b6d3606d", null ],
    [ "accept", "d2/d58/classServerDialog.html#a76b411ccd67891b3c3653ac067e227ec", null ],
    [ "getSecond", "d2/d58/classServerDialog.html#a30491eefdecd1fe8d45b2406d1866eeb", null ],
    [ "getSocket", "d2/d58/classServerDialog.html#a9fe8e0183d0498d2061cf6ecdf840def", null ],
    [ "getTurn", "d2/d58/classServerDialog.html#af9ad20e93451b44ddca05eacabd54507", null ],
    [ "setTurn", "d2/d58/classServerDialog.html#a6a08aaf680827908b17a54654cfcaf80", null ],
    [ "ip", "d2/d58/classServerDialog.html#a44b314996f72070e7f535de425795d97", null ],
    [ "loadingDialog", "d2/d58/classServerDialog.html#afe1ca012a906e6d945e0bfb6b0f1d5df", null ],
    [ "server", "d2/d58/classServerDialog.html#a7467c007bbe57d22731166f86bbc0b24", null ],
    [ "socket", "d2/d58/classServerDialog.html#ab7be1892c53ed28d5167d4872e4b152d", null ],
    [ "ui", "d2/d58/classServerDialog.html#afa306742f46527a5a8aa54cf0e7ad3f5", null ]
];