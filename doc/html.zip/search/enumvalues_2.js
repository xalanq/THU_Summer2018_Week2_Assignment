var searchData=
[
  ['ma',['MA',['../dd/d08/namespaceChess.html#a6fe295b91aa11dd224248c0dc85665b0a5dcc7936a7eadd8e70e7e5b1f556cf5c',1,'Chess']]]
];
