var searchData=
[
  ['panelwidget',['panelWidget',['../d6/d1a/classMainWindow.html#a1d4f30fde8a1fcda4f7008e753b28ae4',1,'MainWindow']]]
];
