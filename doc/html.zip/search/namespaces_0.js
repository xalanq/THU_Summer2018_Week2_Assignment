var searchData=
[
  ['chess',['Chess',['../dd/d08/namespaceChess.html',1,'']]]
];
