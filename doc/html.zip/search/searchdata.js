var indexSectionsWithContent =
{
  0: "abcdefgijlmnpqrstuwxy~åæ",
  1: "clmps",
  2: "cu",
  3: "clmprs",
  4: "acfgilmnpst~",
  5: "bcdeglpqrstuwxy",
  6: "ct",
  7: "bjmnprsx",
  8: "n",
  9: "wåæ"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "files",
  4: "functions",
  5: "variables",
  6: "enums",
  7: "enumvalues",
  8: "defines",
  9: "pages"
};

var indexSectionLabels =
{
  0: "全部",
  1: "类",
  2: "命名空间",
  3: "文件",
  4: "函数",
  5: "变量",
  6: "枚举",
  7: "枚举值",
  8: "宏定义",
  9: "页"
};

