var searchData=
[
  ['ui',['ui',['../d1/d8f/classClientDialog.html#ac30c60a1ac7863b5eb3c6f81dc5d5dbe',1,'ClientDialog::ui()'],['../d6/d1a/classMainWindow.html#a35466a70ed47252a0191168126a352a5',1,'MainWindow::ui()'],['../d3/d3b/classPanelWidget.html#ac2a0b18a5a3f55589c2d70954a731c5f',1,'PanelWidget::ui()'],['../d2/d58/classServerDialog.html#afa306742f46527a5a8aa54cf0e7ad3f5',1,'ServerDialog::ui()']]]
];
