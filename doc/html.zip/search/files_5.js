var searchData=
[
  ['serverdialog_2ecpp',['ServerDialog.cpp',['../d9/d5e/ServerDialog_8cpp.html',1,'']]],
  ['serverdialog_2eh',['ServerDialog.h',['../d8/db7/ServerDialog_8h.html',1,'']]]
];
