var searchData=
[
  ['panelwidget_2ecpp',['PanelWidget.cpp',['../d1/d07/PanelWidget_8cpp.html',1,'']]],
  ['panelwidget_2eh',['PanelWidget.h',['../de/d42/PanelWidget_8h.html',1,'']]]
];
