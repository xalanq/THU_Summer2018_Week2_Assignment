var searchData=
[
  ['dockwidget',['dockWidget',['../d6/d1a/classMainWindow.html#add026ab91c532052d149541db295b140',1,'MainWindow']]]
];
