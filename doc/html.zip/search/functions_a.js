var searchData=
[
  ['timeout',['timeout',['../d3/d3b/classPanelWidget.html#a5263ceb27b3117e69838c91b788f2691',1,'PanelWidget']]],
  ['turn',['turn',['../d3/d6b/classChessWidget.html#ac447b89230a24093460f0e6ac06ef212',1,'ChessWidget']]]
];
