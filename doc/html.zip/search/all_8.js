var searchData=
[
  ['jiang',['JIANG',['../dd/d08/namespaceChess.html#a6fe295b91aa11dd224248c0dc85665b0a9b05f7708b5d25663798eefd18f9c084',1,'Chess']]],
  ['ju',['JU',['../dd/d08/namespaceChess.html#a6fe295b91aa11dd224248c0dc85665b0ac4a344ee18474b0ebc4be647ad9cce5a',1,'Chess']]]
];
