var searchData=
[
  ['nocolor',['NOCOLOR',['../dd/d08/namespaceChess.html#a59a9d4e4128655f58f1b9e44d810b8ddab973530901709e45e8e5fce9a194afbb',1,'Chess']]],
  ['notype',['NOTYPE',['../dd/d08/namespaceChess.html#a6fe295b91aa11dd224248c0dc85665b0a1a802a824c91e8a82b2febfb80115c14',1,'Chess']]]
];
