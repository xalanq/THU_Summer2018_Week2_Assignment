var searchData=
[
  ['shi',['SHI',['../dd/d08/namespaceChess.html#a6fe295b91aa11dd224248c0dc85665b0aeca32da7cb1b3ab749584672fce7fa65',1,'Chess']]]
];
