var searchData=
[
  ['getsecond',['getSecond',['../d2/d58/classServerDialog.html#a30491eefdecd1fe8d45b2406d1866eeb',1,'ServerDialog']]],
  ['getsocket',['getSocket',['../d1/d8f/classClientDialog.html#a518c2975761869531fdf6cf69bbd46d7',1,'ClientDialog::getSocket()'],['../d2/d58/classServerDialog.html#a9fe8e0183d0498d2061cf6ecdf840def',1,'ServerDialog::getSocket()']]],
  ['gettimelimit',['getTimelimit',['../d3/d3b/classPanelWidget.html#ad4733d62af8b38a104a00137102058fb',1,'PanelWidget']]],
  ['getturn',['getTurn',['../d2/d58/classServerDialog.html#af9ad20e93451b44ddca05eacabd54507',1,'ServerDialog']]],
  ['gif',['gif',['../d3/dd5/classLoadingDialog.html#adf3ba0ad11954b9004d396f8d72ba69b',1,'LoadingDialog']]]
];
