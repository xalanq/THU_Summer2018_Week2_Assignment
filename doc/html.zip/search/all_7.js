var searchData=
[
  ['init',['init',['../d3/d6b/classChessWidget.html#aba31ab62ea53d19d3da64241c33cb2f9',1,'ChessWidget::init()'],['../d3/d3b/classPanelWidget.html#a61187edd8a2b60d636fab3a489cd1b9f',1,'PanelWidget::init()'],['../dd/d08/namespaceChess.html#a5a35b9b454fb19baab5ab89ce7ebe5ee',1,'Chess::init()']]],
  ['ip',['ip',['../d2/d58/classServerDialog.html#a44b314996f72070e7f535de425795d97',1,'ServerDialog']]],
  ['isred',['isRed',['../d3/d6b/classChessWidget.html#a412fa7d677c6d89ff6c4cc21884a0f38',1,'ChessWidget']]],
  ['isredturn',['isRedTurn',['../d3/d6b/classChessWidget.html#a5a62b4426207ddb1ca62719add78e870',1,'ChessWidget']]],
  ['iswin',['isWin',['../d3/d6b/classChessWidget.html#a139945fc0a34a3182a4d75fede48e845',1,'ChessWidget']]]
];
