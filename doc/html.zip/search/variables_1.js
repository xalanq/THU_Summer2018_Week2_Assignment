var searchData=
[
  ['clientdialog',['clientDialog',['../d6/d1a/classMainWindow.html#a1411e140871022688e829b8b04994230',1,'MainWindow']]],
  ['color',['color',['../d3/d6b/classChessWidget.html#a4440e4ee8810568af7789783c817fc2e',1,'ChessWidget::color()'],['../dd/d08/namespaceChess.html#afaf16b8dd263063e8259ef5ec404724a',1,'Chess::color()']]]
];
