var searchData=
[
  ['red',['RED',['../dd/d08/namespaceChess.html#a59a9d4e4128655f58f1b9e44d810b8dda45ec3bd6d4fa03152f12d181a0f944c0',1,'Chess']]]
];
