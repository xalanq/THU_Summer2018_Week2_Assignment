var searchData=
[
  ['pao',['PAO',['../dd/d08/namespaceChess.html#a6fe295b91aa11dd224248c0dc85665b0af067e8e13ae5b6d7cf9d948321088abc',1,'Chess']]]
];
