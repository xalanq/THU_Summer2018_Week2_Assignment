var searchData=
[
  ['chesswidget',['ChessWidget',['../d3/d6b/classChessWidget.html',1,'']]],
  ['clientdialog',['ClientDialog',['../d1/d8f/classClientDialog.html',1,'']]]
];
