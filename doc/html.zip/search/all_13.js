var searchData=
[
  ['x',['x',['../d0/d1c/structChess_1_1Pos.html#a1f74ea44ebaad0599a7cafe85866298c',1,'Chess::Pos']]],
  ['xiang',['XIANG',['../dd/d08/namespaceChess.html#a6fe295b91aa11dd224248c0dc85665b0ab6229b1c5b8609bedc9114bf9ad04f1c',1,'Chess']]]
];
