var searchData=
[
  ['loadcanju',['loadCanju',['../d3/d6b/classChessWidget.html#ae1d238de59742aa4262116e5b08b2f50',1,'ChessWidget']]],
  ['loadcanjufromfile',['loadCanjuFromFile',['../d3/d6b/classChessWidget.html#a35072479c39cdeda6b5dfe00043e8c39',1,'ChessWidget']]],
  ['loadingdialog',['LoadingDialog',['../d3/dd5/classLoadingDialog.html#ab5f859376090c3e4d90cc0d5106f7713',1,'LoadingDialog']]]
];
