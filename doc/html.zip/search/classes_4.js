var searchData=
[
  ['serverdialog',['ServerDialog',['../d2/d58/classServerDialog.html',1,'']]]
];
