var searchData=
[
  ['x',['x',['../d0/d1c/structChess_1_1Pos.html#a1f74ea44ebaad0599a7cafe85866298c',1,'Chess::Pos']]]
];
