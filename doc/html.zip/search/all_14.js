var searchData=
[
  ['y',['y',['../d0/d1c/structChess_1_1Pos.html#a5415e99048f4370bcf5980c3df6d468a',1,'Chess::Pos']]]
];
