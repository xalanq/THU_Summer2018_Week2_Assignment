var searchData=
[
  ['end',['end',['../d3/d6b/classChessWidget.html#a631553735b02d1a7da5773e88ff811d8',1,'ChessWidget']]]
];
