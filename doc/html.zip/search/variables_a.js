var searchData=
[
  ['tm',['tm',['../d3/d6b/classChessWidget.html#a2e397bf2cb071b10e8e86db081a41b91',1,'ChessWidget::tm()'],['../d3/d3b/classPanelWidget.html#adc599e844266b38ee732c133bfc9bc2d',1,'PanelWidget::tm()']]],
  ['turncolor',['turnColor',['../d3/d6b/classChessWidget.html#ac99bea3f98b92a4019a36d3d9ea51c60',1,'ChessWidget']]],
  ['type',['type',['../dd/d08/namespaceChess.html#ad03ea1ea6bcc1869e8dfd0b031a8bbd9',1,'Chess']]]
];
