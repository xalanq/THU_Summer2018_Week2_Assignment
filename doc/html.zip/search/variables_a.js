var searchData=
[
  ['sec',['sec',['../d3/d3b/classPanelWidget.html#a00328169eb882d6076bc2919887f5ed9',1,'PanelWidget']]],
  ['selshow',['selShow',['../d3/d6b/classChessWidget.html#a423cc89b6321f95f199503d148c607b8',1,'ChessWidget']]],
  ['selx',['selX',['../d3/d6b/classChessWidget.html#a2085c2626c76d0bff5f4ba1a6c648134',1,'ChessWidget']]],
  ['sely',['selY',['../d3/d6b/classChessWidget.html#a2e994547a1f8f4a49841c4e6bb0be92f',1,'ChessWidget']]],
  ['server',['server',['../d2/d58/classServerDialog.html#a7467c007bbe57d22731166f86bbc0b24',1,'ServerDialog']]],
  ['serverdialog',['serverDialog',['../d6/d1a/classMainWindow.html#a49daf42880ba8eb14d370f3d110c32cb',1,'MainWindow']]],
  ['socket',['socket',['../d1/d8f/classClientDialog.html#ae6c8623f30f5427927b109e63606c511',1,'ClientDialog::socket()'],['../d6/d1a/classMainWindow.html#af85cfe62c116f8d2f2021e5411b0356e',1,'MainWindow::socket()'],['../d2/d58/classServerDialog.html#ab7be1892c53ed28d5167d4872e4b152d',1,'ServerDialog::socket()']]],
  ['soundchi',['soundChi',['../d3/d6b/classChessWidget.html#a24a64559d2ba8d409d82626405470e2f',1,'ChessWidget']]],
  ['soundjiangjun',['soundJiangjun',['../d3/d6b/classChessWidget.html#aa4a1fe0b28fafdeefa1d74bc810f889c',1,'ChessWidget']]],
  ['soundlose',['soundLose',['../d6/d1a/classMainWindow.html#ab744a4df0dfc7db6fe53b4be0a9b64eb',1,'MainWindow']]],
  ['soundmove',['soundMove',['../d3/d6b/classChessWidget.html#a79c19db3641538f1f0dc11a00bd5d646',1,'ChessWidget']]],
  ['sounds',['sounds',['../d3/d3b/classPanelWidget.html#a6a32b24f71372ea52fef824599029082',1,'PanelWidget']]],
  ['soundstart',['soundStart',['../d6/d1a/classMainWindow.html#a685921f87883e197722d27d467eda04b',1,'MainWindow']]],
  ['soundwarning',['soundWarning',['../d3/d6b/classChessWidget.html#ada13f9c033af979abde854d6615cff8a',1,'ChessWidget']]],
  ['soundwin',['soundWin',['../d6/d1a/classMainWindow.html#a5600163f63aaf2706bf618a2264a91ed',1,'MainWindow']]]
];
