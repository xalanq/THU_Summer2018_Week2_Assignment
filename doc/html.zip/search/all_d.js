var searchData=
[
  ['qi_5fwidth',['QI_WIDTH',['../d3/d6b/classChessWidget.html#a00f36085a53c7088d439552262573926',1,'ChessWidget']]]
];
