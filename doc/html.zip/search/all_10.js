var searchData=
[
  ['timeout',['timeout',['../d3/d3b/classPanelWidget.html#a5263ceb27b3117e69838c91b788f2691',1,'PanelWidget']]],
  ['tm',['tm',['../d3/d6b/classChessWidget.html#a2e397bf2cb071b10e8e86db081a41b91',1,'ChessWidget::tm()'],['../d3/d3b/classPanelWidget.html#adc599e844266b38ee732c133bfc9bc2d',1,'PanelWidget::tm()']]],
  ['turn',['turn',['../d3/d6b/classChessWidget.html#ac447b89230a24093460f0e6ac06ef212',1,'ChessWidget']]],
  ['turncolor',['turnColor',['../d3/d6b/classChessWidget.html#ac99bea3f98b92a4019a36d3d9ea51c60',1,'ChessWidget']]],
  ['type',['Type',['../dd/d08/namespaceChess.html#a6fe295b91aa11dd224248c0dc85665b0',1,'Chess::Type()'],['../dd/d08/namespaceChess.html#ad03ea1ea6bcc1869e8dfd0b031a8bbd9',1,'Chess::type()']]]
];
