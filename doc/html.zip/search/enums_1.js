var searchData=
[
  ['type',['Type',['../dd/d08/namespaceChess.html#a6fe295b91aa11dd224248c0dc85665b0',1,'Chess']]]
];
