var searchData=
[
  ['color',['Color',['../dd/d08/namespaceChess.html#a59a9d4e4128655f58f1b9e44d810b8dd',1,'Chess']]]
];
