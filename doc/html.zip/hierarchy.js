var hierarchy =
[
    [ "Chess::Pos", "d0/d1c/structChess_1_1Pos.html", null ],
    [ "QDialog", null, [
      [ "ClientDialog", "d1/d8f/classClientDialog.html", null ],
      [ "LoadingDialog", "d3/dd5/classLoadingDialog.html", null ],
      [ "ServerDialog", "d2/d58/classServerDialog.html", null ]
    ] ],
    [ "QMainWindow", null, [
      [ "MainWindow", "d6/d1a/classMainWindow.html", null ]
    ] ],
    [ "QWidget", null, [
      [ "ChessWidget", "d3/d6b/classChessWidget.html", null ],
      [ "PanelWidget", "d3/d3b/classPanelWidget.html", null ]
    ] ]
];