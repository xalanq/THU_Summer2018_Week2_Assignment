var namespaces_dup =
[
    [ "Chess", "dd/d08/namespaceChess.html", null ],
    [ "Ui", "db/d3c/namespaceUi.html", null ]
];