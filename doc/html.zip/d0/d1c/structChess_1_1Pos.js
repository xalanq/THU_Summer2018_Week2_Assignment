var structChess_1_1Pos =
[
    [ "Pos", "d0/d1c/structChess_1_1Pos.html#a2b1717d081a66ac3c027fa760224fe6d", null ],
    [ "x", "d0/d1c/structChess_1_1Pos.html#a1f74ea44ebaad0599a7cafe85866298c", null ],
    [ "y", "d0/d1c/structChess_1_1Pos.html#a5415e99048f4370bcf5980c3df6d468a", null ]
];