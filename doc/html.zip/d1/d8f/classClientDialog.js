var classClientDialog =
[
    [ "ClientDialog", "d1/d8f/classClientDialog.html#ab538ca9f16d507703a91ea51db351219", null ],
    [ "~ClientDialog", "d1/d8f/classClientDialog.html#ac5b87269dcf54c1676bd0c7b7e1d34cf", null ],
    [ "accept", "d1/d8f/classClientDialog.html#ae84b1a1289f1eb38ef085344f4d6d566", null ],
    [ "getSocket", "d1/d8f/classClientDialog.html#a518c2975761869531fdf6cf69bbd46d7", null ],
    [ "loadingDialog", "d1/d8f/classClientDialog.html#a3fde63712ecc8fd70cc9b133466ba2f0", null ],
    [ "reg", "d1/d8f/classClientDialog.html#a4721d2377eb4e5ec235860956deaf5a8", null ],
    [ "socket", "d1/d8f/classClientDialog.html#ae6c8623f30f5427927b109e63606c511", null ],
    [ "ui", "d1/d8f/classClientDialog.html#ac30c60a1ac7863b5eb3c6f81dc5d5dbe", null ]
];