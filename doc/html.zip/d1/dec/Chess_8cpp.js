var Chess_8cpp =
[
    [ "checkDuiJiang", "d1/dec/Chess_8cpp.html#a03d901acc6b52980e3d744850e04f837", null ],
    [ "checkJiang", "d1/dec/Chess_8cpp.html#aa5a2b81245c7694ada1db2695c3afda1", null ],
    [ "checkWin", "d1/dec/Chess_8cpp.html#a9a413ba30bdb5c3c49014a5b92d991a5", null ],
    [ "clear", "d1/dec/Chess_8cpp.html#a2c0f32cb527d6cd6afd4b41b9ca74293", null ],
    [ "f", "d1/dec/Chess_8cpp.html#a130370beabefd779a881e12c05407124", null ],
    [ "init", "d1/dec/Chess_8cpp.html#a5a35b9b454fb19baab5ab89ce7ebe5ee", null ],
    [ "moveTo", "d1/dec/Chess_8cpp.html#a01665ddb539af0391678f54f3473724a", null ],
    [ "possibleMove", "d1/dec/Chess_8cpp.html#af2480f12672e99129d56535661a15b6d", null ],
    [ "color", "d1/dec/Chess_8cpp.html#afaf16b8dd263063e8259ef5ec404724a", null ],
    [ "type", "d1/dec/Chess_8cpp.html#ad03ea1ea6bcc1869e8dfd0b031a8bbd9", null ]
];