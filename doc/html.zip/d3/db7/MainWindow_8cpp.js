var MainWindow_8cpp =
[
    [ "netWriteBegin", "d3/db7/MainWindow_8cpp.html#a95cbe73a6a07a7788962568da9c0025b", null ],
    [ "netWriteEnd", "d3/db7/MainWindow_8cpp.html#a613414d35165ad693863fa6591036599", null ]
];