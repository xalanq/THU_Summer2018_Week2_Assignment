var classPanelWidget =
[
    [ "PanelWidget", "d3/d3b/classPanelWidget.html#a6700702b5fb330d465c27d6f7d88421d", null ],
    [ "~PanelWidget", "d3/d3b/classPanelWidget.html#a0c47b834c0e3d56cb51c96e44ea620b2", null ],
    [ "clickedRenshu", "d3/d3b/classPanelWidget.html#a5ebc92a56ef8735a1b1eb70891d141f3", null ],
    [ "getTimelimit", "d3/d3b/classPanelWidget.html#ad4733d62af8b38a104a00137102058fb", null ],
    [ "init", "d3/d3b/classPanelWidget.html#a61187edd8a2b60d636fab3a489cd1b9f", null ],
    [ "setRenshuEnabled", "d3/d3b/classPanelWidget.html#af0f5c6dde4b23c1049b7c0cb41c20e5b", null ],
    [ "setTimelimit", "d3/d3b/classPanelWidget.html#a1e3e7263c66de94fa5e74cdc9a84c177", null ],
    [ "setTurn", "d3/d3b/classPanelWidget.html#a903f68e8b7493e1d99a6eaebdb9fc09e", null ],
    [ "timeout", "d3/d3b/classPanelWidget.html#a5263ceb27b3117e69838c91b788f2691", null ],
    [ "limit", "d3/d3b/classPanelWidget.html#a1f253f9009a6bd6c6cdfac4b4d9518cc", null ],
    [ "sec", "d3/d3b/classPanelWidget.html#a00328169eb882d6076bc2919887f5ed9", null ],
    [ "sounds", "d3/d3b/classPanelWidget.html#a6a32b24f71372ea52fef824599029082", null ],
    [ "tm", "d3/d3b/classPanelWidget.html#adc599e844266b38ee732c133bfc9bc2d", null ],
    [ "ui", "d3/d3b/classPanelWidget.html#ac2a0b18a5a3f55589c2d70954a731c5f", null ]
];