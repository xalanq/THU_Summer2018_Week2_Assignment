var Chess_8h =
[
    [ "Pos", "d0/d1c/structChess_1_1Pos.html", "d0/d1c/structChess_1_1Pos" ],
    [ "Color", "dc/d1b/Chess_8h.html#a59a9d4e4128655f58f1b9e44d810b8dd", [
      [ "RED", "dc/d1b/Chess_8h.html#a59a9d4e4128655f58f1b9e44d810b8dda45ec3bd6d4fa03152f12d181a0f944c0", null ],
      [ "BLACK", "dc/d1b/Chess_8h.html#a59a9d4e4128655f58f1b9e44d810b8dda0c3bff813a01db94a206ba2d68f114d8", null ],
      [ "NOCOLOR", "dc/d1b/Chess_8h.html#a59a9d4e4128655f58f1b9e44d810b8ddab973530901709e45e8e5fce9a194afbb", null ]
    ] ],
    [ "Type", "dc/d1b/Chess_8h.html#a6fe295b91aa11dd224248c0dc85665b0", [
      [ "JIANG", "dc/d1b/Chess_8h.html#a6fe295b91aa11dd224248c0dc85665b0a9b05f7708b5d25663798eefd18f9c084", null ],
      [ "SHI", "dc/d1b/Chess_8h.html#a6fe295b91aa11dd224248c0dc85665b0aeca32da7cb1b3ab749584672fce7fa65", null ],
      [ "XIANG", "dc/d1b/Chess_8h.html#a6fe295b91aa11dd224248c0dc85665b0ab6229b1c5b8609bedc9114bf9ad04f1c", null ],
      [ "MA", "dc/d1b/Chess_8h.html#a6fe295b91aa11dd224248c0dc85665b0a5dcc7936a7eadd8e70e7e5b1f556cf5c", null ],
      [ "JU", "dc/d1b/Chess_8h.html#a6fe295b91aa11dd224248c0dc85665b0ac4a344ee18474b0ebc4be647ad9cce5a", null ],
      [ "PAO", "dc/d1b/Chess_8h.html#a6fe295b91aa11dd224248c0dc85665b0af067e8e13ae5b6d7cf9d948321088abc", null ],
      [ "BING", "dc/d1b/Chess_8h.html#a6fe295b91aa11dd224248c0dc85665b0a268cd14d33d3b723864c282136e7565e", null ],
      [ "NOTYPE", "dc/d1b/Chess_8h.html#a6fe295b91aa11dd224248c0dc85665b0a1a802a824c91e8a82b2febfb80115c14", null ]
    ] ],
    [ "checkDuiJiang", "dc/d1b/Chess_8h.html#a03d901acc6b52980e3d744850e04f837", null ],
    [ "checkJiang", "dc/d1b/Chess_8h.html#aa5a2b81245c7694ada1db2695c3afda1", null ],
    [ "checkWin", "dc/d1b/Chess_8h.html#a9a413ba30bdb5c3c49014a5b92d991a5", null ],
    [ "clear", "dc/d1b/Chess_8h.html#a2c0f32cb527d6cd6afd4b41b9ca74293", null ],
    [ "f", "dc/d1b/Chess_8h.html#a130370beabefd779a881e12c05407124", null ],
    [ "init", "dc/d1b/Chess_8h.html#a5a35b9b454fb19baab5ab89ce7ebe5ee", null ],
    [ "moveTo", "dc/d1b/Chess_8h.html#a01665ddb539af0391678f54f3473724a", null ],
    [ "possibleMove", "dc/d1b/Chess_8h.html#af2480f12672e99129d56535661a15b6d", null ]
];