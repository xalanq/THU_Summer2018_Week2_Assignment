var dir_68267d1309a1af8e8297ef4c3efbcdba =
[
    [ "Chess.cpp", "d1/dec/Chess_8cpp.html", "d1/dec/Chess_8cpp" ],
    [ "Chess.h", "dc/d1b/Chess_8h.html", "dc/d1b/Chess_8h" ],
    [ "ChessWidget.cpp", "d0/d6d/ChessWidget_8cpp.html", null ],
    [ "ChessWidget.h", "dd/dab/ChessWidget_8h.html", [
      [ "ChessWidget", "d3/d6b/classChessWidget.html", "d3/d6b/classChessWidget" ]
    ] ],
    [ "ClientDialog.cpp", "d1/dd8/ClientDialog_8cpp.html", null ],
    [ "ClientDialog.h", "da/daa/ClientDialog_8h.html", [
      [ "ClientDialog", "d1/d8f/classClientDialog.html", "d1/d8f/classClientDialog" ]
    ] ],
    [ "LoadingDialog.cpp", "de/dbe/LoadingDialog_8cpp.html", null ],
    [ "LoadingDialog.h", "da/df1/LoadingDialog_8h.html", [
      [ "LoadingDialog", "d3/dd5/classLoadingDialog.html", "d3/dd5/classLoadingDialog" ]
    ] ],
    [ "main.cpp", "df/d0a/main_8cpp.html", "df/d0a/main_8cpp" ],
    [ "MainWindow.cpp", "d3/db7/MainWindow_8cpp.html", "d3/db7/MainWindow_8cpp" ],
    [ "MainWindow.h", "da/d9c/MainWindow_8h.html", [
      [ "MainWindow", "d6/d1a/classMainWindow.html", "d6/d1a/classMainWindow" ]
    ] ],
    [ "PanelWidget.cpp", "d1/d07/PanelWidget_8cpp.html", null ],
    [ "PanelWidget.h", "de/d42/PanelWidget_8h.html", [
      [ "PanelWidget", "d3/d3b/classPanelWidget.html", "d3/d3b/classPanelWidget" ]
    ] ],
    [ "ServerDialog.cpp", "d9/d5e/ServerDialog_8cpp.html", null ],
    [ "ServerDialog.h", "d8/db7/ServerDialog_8h.html", [
      [ "ServerDialog", "d2/d58/classServerDialog.html", "d2/d58/classServerDialog" ]
    ] ]
];